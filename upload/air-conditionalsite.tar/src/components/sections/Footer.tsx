"use client";

import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Snowflake,
  Facebook,
  Instagram,
  Youtube,
} from "lucide-react";

const quickLinks = [
  { label: "Home", href: "home" },
  { label: "About Us", href: "about" },
  { label: "Services", href: "services" },
  { label: "Contact Us", href: "contact" },
];

const serviceLinks = [
  { label: "Electronic Diagnostics", href: "diagnostic" },
  { label: "Repair & Maintenance", href: "repair" },
  { label: "Refrigerant Recharge", href: "recharge" },
  { label: "System Cleaning", href: "cleaning" },
];

const socialLinks = [
  { icon: Facebook, href: "#", label: "Facebook" },
  { icon: Instagram, href: "#", label: "Instagram" },
  { icon: Youtube, href: "#", label: "YouTube" },
];

export default function Footer({
  onNavigate,
}: {
  onNavigate: (view: { type: "home" } | { type: "service"; id: string }) => void;
}) {
  const handleQuickLink = (href: string) => {
    onNavigate({ type: "home" });
    setTimeout(() => {
      const element = document.querySelector(`#${href}`);
      if (element) element.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const handleServiceLink = (id: string) => {
    onNavigate({ type: "service", id });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-brand-purple-dark text-white">
      {/* Main footer */}
      <div className="container mx-auto px-4 py-14">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand column */}
          <div className="sm:col-span-2 lg:col-span-1">
            <button onClick={() => onNavigate({ type: "home" })} className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                <Snowflake className="h-5 w-5 text-brand-yellow" />
              </div>
              <div className="flex flex-col">
                <span className="text-brand-red-light font-extrabold text-lg leading-tight">
                  MASTECH
                </span>
                <span className="text-brand-yellow-light text-[10px] font-semibold tracking-wider uppercase leading-tight">
                  Cooling Technology
                </span>
              </div>
            </button>
            <p className="text-white/60 text-sm leading-relaxed mb-5">
              Your trusted partner for all your car air conditioning needs.
              Experts in AC system diagnostics, repair, and maintenance.
            </p>
            <div className="flex items-center gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="w-9 h-9 rounded-lg bg-white/10 hover:bg-brand-yellow hover:text-brand-purple-dark flex items-center justify-center transition-all duration-300"
                >
                  <social.icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-bold text-base mb-5 text-brand-yellow-light">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <button
                    onClick={() => handleQuickLink(link.href)}
                    className="text-white/60 hover:text-white text-sm transition-colors duration-200 flex items-center gap-2"
                  >
                    <span className="w-1 h-1 rounded-full bg-brand-yellow/50" />
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services links */}
          <div>
            <h4 className="font-bold text-base mb-5 text-brand-yellow-light">
              Our Services
            </h4>
            <ul className="space-y-3">
              {serviceLinks.map((link) => (
                <li key={link.href}>
                  <button
                    onClick={() => handleServiceLink(link.href)}
                    className="text-white/60 hover:text-white text-sm transition-colors duration-200 flex items-center gap-2 text-left"
                  >
                    <span className="w-1 h-1 rounded-full bg-brand-yellow/50" />
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact info */}
          <div>
            <h4 className="font-bold text-base mb-5 text-brand-yellow-light">
              Contact Info
            </h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="h-4 w-4 text-brand-yellow mt-0.5 flex-shrink-0" />
                <span className="text-white/60 text-sm">
                  Industrial Zone, Antananarivo, Madagascar
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-brand-yellow flex-shrink-0" />
                <a
                  href="tel:0244608104"
                  className="text-white/60 hover:text-white text-sm transition-colors"
                >
                  0244 608 104
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-brand-yellow flex-shrink-0" />
                <a
                  href="mailto:contact@mastechcooling.com"
                  className="text-white/60 hover:text-white text-sm transition-colors"
                >
                  contact@mastechcooling.com
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Clock className="h-4 w-4 text-brand-yellow mt-0.5 flex-shrink-0" />
                <span className="text-white/60 text-sm">
                  Mon - Sat: 8:00 AM - 6:00 PM
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-white/40 text-xs">
            &copy; {new Date().getFullYear()} Mastech Cooling Technology. All rights reserved.
          </p>
          <p className="text-white/40 text-xs">
            Masters in Cooling — Car Air Conditioning Experts
          </p>
        </div>
      </div>
    </footer>
  );
}
