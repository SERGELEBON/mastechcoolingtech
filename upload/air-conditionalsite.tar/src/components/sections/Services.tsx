"use client";

import { motion } from "framer-motion";
import {
  Search,
  Wrench,
  Droplets,
  Sparkles,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ServiceId } from "@/lib/services-data";

const serviceCards: {
  id: ServiceId;
  icon: typeof Search;
  image: string;
  title: string;
  subtitle: string;
  shortDescription: string;
  color: string;
}[] = [
  {
    id: "diagnostic",
    icon: Search,
    image: "/service-diagnostic.png",
    title: "Electronic Diagnostics",
    subtitle: "Precise fault detection",
    shortDescription:
      "Using state-of-the-art computerized tools, we precisely locate faults in your air conditioning system. Our electronic diagnostic equipment analyzes every component to identify the exact source of the problem.",
    color: "from-brand-purple to-brand-purple-light",
  },
  {
    id: "repair",
    icon: Wrench,
    image: "/service-repair.png",
    title: "Repair & Maintenance",
    subtitle: "Compressors, condensers, evaporators",
    shortDescription:
      "Our qualified technicians work on all major components of your air conditioning system. Whether for the repair or replacement of compressors, condensers, evaporators or expansion valves, we ensure meticulous, professional work.",
    color: "from-brand-red to-brand-red-light",
  },
  {
    id: "recharge",
    icon: Droplets,
    image: "/service-recharge.png",
    title: "Refrigerant Recharge",
    subtitle: "Professional AC gas service",
    shortDescription:
      "The refrigerant recharge process is essential to restore efficient air conditioning. We perform a complete circuit flush, rigorous leak test, then a recharge with the gas adapted to your vehicle (R134a or R1234yf).",
    color: "from-brand-purple to-brand-purple-light",
  },
  {
    id: "cleaning",
    icon: Sparkles,
    image: "/service-cleaning.png",
    title: "System Cleaning",
    subtitle: "Longevity & performance",
    shortDescription:
      "Deep cleaning of your air conditioning system removes accumulated debris, moisture and bacteria that impair performance and air quality. This preventive treatment guarantees the longevity of your components.",
    color: "from-brand-red to-brand-red-light",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.2 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

export default function Services({
  onNavigateToService,
}: {
  onNavigateToService: (id: ServiceId) => void;
}) {
  const handleScrollTo = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="services" className="py-20 lg:py-28 bg-muted/50">
      <div className="container mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <span className="inline-block text-brand-purple font-semibold text-sm uppercase tracking-wider mb-3">
            What We Offer
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-foreground mb-4">
            Our <span className="text-brand-purple">Services</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Professional solutions for all your car air conditioning needs. Each
            service is performed with expertise and cutting-edge equipment.
          </p>
        </motion.div>

        {/* Services grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid md:grid-cols-2 gap-8"
        >
          {serviceCards.map((service) => (
            <motion.div
              key={service.id}
              variants={cardVariants}
              className="group bg-card rounded-2xl overflow-hidden border border-border hover:shadow-xl transition-all duration-500 hover:border-brand-purple/30 flex flex-col"
            >
              {/* Image with overlay */}
              <div className="relative h-56 overflow-hidden cursor-pointer" onClick={() => onNavigateToService(service.id)}>
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${service.color} opacity-60`} />
                <div className="absolute bottom-4 left-4 flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                    <service.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">
                      {service.title}
                    </h3>
                    <p className="text-white/80 text-sm">{service.subtitle}</p>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 flex flex-col flex-1">
                <p className="text-muted-foreground leading-relaxed mb-5">
                  {service.shortDescription}
                </p>
                <Button
                  variant="outline"
                  onClick={() => onNavigateToService(service.id)}
                  className="mt-auto w-fit group/btn border-brand-purple/30 text-brand-purple hover:bg-brand-purple hover:text-white"
                >
                  Learn More
                  <ArrowRight className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                </Button>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-center mt-16"
        >
          <Button
            onClick={() => handleScrollTo("#contact")}
            size="lg"
            className="bg-brand-purple hover:bg-brand-purple-light text-white font-semibold text-base px-8 h-12"
          >
            Request a Quote
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
