"use client";

import { motion } from "framer-motion";
import { Snowflake, Phone, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Hero({
  onNavigate,
}: {
  onNavigate: (view: { type: "home" } | { type: "service"; id: string }) => void;
}) {
  const handleScrollTo = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-[90vh] flex items-center overflow-hidden"
    >
      {/* Background image with overlay */}
      <div className="absolute inset-0">
        <img
          src="/hero-bg.png"
          alt="Mastech car air conditioning service workshop"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-brand-purple-dark/95 via-brand-purple/85 to-brand-purple-dark/70" />
        <div className="absolute inset-0 bg-gradient-to-t from-brand-purple-dark/50 to-transparent" />
      </div>

      {/* Decorative elements */}
      <div className="absolute top-20 right-10 opacity-10">
        <Snowflake className="h-64 w-64 text-white animate-spin" style={{ animationDuration: "30s" }} />
      </div>
      <div className="absolute bottom-20 left-10 opacity-5">
        <Snowflake className="h-48 w-48 text-white animate-spin" style={{ animationDuration: "45s", animationDirection: "reverse" }} />
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 py-20">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2 mb-6">
              <Snowflake className="h-4 w-4 text-brand-yellow" />
              <span className="text-brand-yellow-light text-sm font-medium">
                Car Air Conditioning Experts
              </span>
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight mb-6"
          >
            <span className="text-brand-red">MASTECH</span>
            <br />
            <span className="text-brand-yellow">Cooling</span>{" "}
            <span className="text-white">Technology</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg sm:text-xl text-white/80 mb-4 max-w-xl"
          >
            Your trusted partner for all your car air conditioning needs.
            Diagnostics, repair, recharge and maintenance of your AC system
            performed by certified experts.
          </motion.p>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.25 }}
            className="text-base text-brand-gold italic mb-8"
          >
            &ldquo;Masters in Cooling&rdquo;
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap gap-4"
          >
            <Button
              onClick={() => handleScrollTo("#services")}
              size="lg"
              className="bg-brand-red hover:bg-brand-red-light text-white font-semibold text-base px-8 h-12"
            >
              Our Services
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 font-semibold text-base px-8 h-12"
            >
              <a href="tel:0244608104" className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                0244 608 104
              </a>
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.6 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <button
          onClick={() => handleScrollTo("#about")}
          className="flex flex-col items-center gap-2 text-white/60 hover:text-white/80 transition-colors"
          aria-label="Scroll down"
        >
          <span className="text-xs uppercase tracking-widest">Discover</span>
          <ArrowDown className="h-4 w-4 animate-bounce" />
        </button>
      </motion.div>
    </section>
  );
}
