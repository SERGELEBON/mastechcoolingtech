"use client";

import { useState, useEffect, useCallback } from "react";
import Header from "@/components/sections/Header";
import Hero from "@/components/sections/Hero";
import About from "@/components/sections/About";
import Services from "@/components/sections/Services";
import Contact from "@/components/sections/Contact";
import Footer from "@/components/sections/Footer";
import ServiceDetail from "@/components/sections/ServiceDetail";
import type { ServiceId } from "@/lib/services-data";

type View = { type: "home" } | { type: "service"; id: ServiceId };

const validServiceIds: ServiceId[] = ["diagnostic", "repair", "recharge", "cleaning"];

function parseHash(): View {
  if (typeof window === "undefined") return { type: "home" };
  const hash = window.location.hash.replace(/^#\/?/, "");
  if (hash.startsWith("services/")) {
    const id = hash.replace("services/", "") as ServiceId;
    if (validServiceIds.includes(id)) {
      return { type: "service", id };
    }
  }
  return { type: "home" };
}

function viewToHash(view: View): string {
  if (view.type === "service") {
    return `#/services/${view.id}`;
  }
  return "#/";
}

export default function Home() {
  const [view, setView] = useState<View>(() => parseHash());

  const handleNavigate = useCallback((newView: View) => {
    setView(newView);
    const newHash = viewToHash(newView);
    if (window.location.hash !== newHash) {
      window.history.pushState({ view: newView }, "", newHash);
    }
  }, []);

  // Listen for back/forward navigation
  useEffect(() => {
    const handlePopState = () => {
      const parsed = parseHash();
      setView(parsed);
    };

    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  // Scroll to top when view changes to a service detail
  useEffect(() => {
    if (view.type === "service") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [view]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header currentView={view} onNavigate={handleNavigate} />
      {view.type === "home" ? (
        <main className="flex-1">
          <Hero onNavigate={handleNavigate} />
          <About />
          <Services onNavigateToService={(id) => handleNavigate({ type: "service", id })} />
          <Contact />
        </main>
      ) : (
        <ServiceDetail serviceId={view.id} onNavigate={handleNavigate} />
      )}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
